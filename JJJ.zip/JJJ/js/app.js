/* ============================================================
   Patently — main script
   ============================================================ */

   document.addEventListener('DOMContentLoaded', function () {

    /* --------------------------------------------------------
       1. Плавная прокрутка для якорных ссылок
       -------------------------------------------------------- */
    var anchors = document.querySelectorAll('a[href^="#"]');

    anchors.forEach(function (link) {
        link.addEventListener('click', function (e) {
            var targetId = this.getAttribute('href');

            if (targetId === '#' || targetId.length < 2) return;

            var target = document.querySelector(targetId);

            if (target) {
                e.preventDefault();
                var headerOffset = 80;
                var top = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;

                window.scrollTo({
                    top: top,
                    behavior: 'smooth'
                });
            }
        });
    });


    /* --------------------------------------------------------
       2. Подсветка активного пункта меню при скролле
       -------------------------------------------------------- */
    var sections = document.querySelectorAll('section[id]');
    var navLinks = document.querySelectorAll('.nav-link');

    function highlightNav() {
        var scrollPos = window.pageYOffset + 120;

        sections.forEach(function (section) {
            var top = section.offsetTop;
            var bottom = top + section.offsetHeight;
            var id = section.getAttribute('id');

            if (scrollPos >= top && scrollPos < bottom) {
                navLinks.forEach(function (link) {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + id) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }

    window.addEventListener('scroll', highlightNav);


    /* --------------------------------------------------------
       3. Обработка формы обратной связи
       -------------------------------------------------------- */
    var contactForm = document.querySelector('.contact-form');

    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();

            var submitBtn = contactForm.querySelector('button[type="submit"]');
            var originalText = submitBtn.textContent;

            // Собираем данные формы
            var formData = {
                firstName: contactForm.querySelector('input[type="text"]').value.trim(),
                email: contactForm.querySelector('input[type="email"]').value.trim(),
                phone: contactForm.querySelector('input[type="tel"]').value.trim(),
                message: contactForm.querySelector('textarea').value.trim()
            };

            // Простая валидация
            if (!formData.firstName || !formData.email) {
                showMessage('Please fill in all required fields.', 'error');
                return;
            }

            if (!isValidEmail(formData.email)) {
                showMessage('Please enter a valid email address.', 'error');
                return;
            }

            // Блокируем кнопку и показываем процесс
            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending...';

            // Имитация отправки на сервер
            setTimeout(function () {
                console.log('Form data:', formData);

                submitBtn.textContent = 'Sent!';
                submitBtn.style.background = '#28a745';
                submitBtn.style.color = '#ffffff';

                showMessage('Thank you! We will contact you soon.', 'success');

                setTimeout(function () {
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                    submitBtn.style.background = '';
                    submitBtn.style.color = '';
                    contactForm.reset();
                }, 2000);
            }, 1200);
        });
    }


    /* --------------------------------------------------------
       4. Всплывающее уведомление
       -------------------------------------------------------- */
    function showMessage(text, type) {
        var existing = document.querySelector('.toast-message');
        if (existing) existing.remove();

        var toast = document.createElement('div');
        toast.className = 'toast-message toast-' + type;
        toast.textContent = text;

        document.body.appendChild(toast);

        setTimeout(function () {
            toast.classList.add('toast-visible');
        }, 10);

        setTimeout(function () {
            toast.classList.remove('toast-visible');
            setTimeout(function () {
                toast.remove();
            }, 300);
        }, 3000);
    }


    /* --------------------------------------------------------
       5. Проверка email
       -------------------------------------------------------- */
    function isValidEmail(email) {
        var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return pattern.test(email);
    }


    /* --------------------------------------------------------
       6. Карусель отзывов (стрелки)
       -------------------------------------------------------- */
    var testimonialGrid = document.querySelector('.testimonials-grid');
    var arrowBtns = document.querySelectorAll('.arrow-btn');
    var pageIndicator = document.querySelector('.testimonials-footer span');

    var testimonialSets = [
        [
            { stars: 5, title: 'Exceptional Service!', text: 'Our experience with Patentify was outstanding. The dedication and professionalism of their team made it easy to choose a system for our work.', name: 'Wade Warren', location: 'USA, California', img: 'https://i.pravatar.cc/60?img=12' },
            { stars: 5, title: 'Efficient and Reliable', text: 'Patentify provided us with top-notch service. They helped us meet our deadlines quickly and at a fair price.', name: 'Emelie Thomson', location: 'USA, Florida', img: 'https://i.pravatar.cc/60?img=45' },
            { stars: 5, title: 'Trusted Professionals', text: 'The Patentify team accompanied us throughout the entire purchase process. Their knowledge was impressive.', name: 'John Mans', location: 'USA, Nevada', img: 'https://i.pravatar.cc/60?img=33' }
        ],
        [
            { stars: 5, title: 'Fast and Accurate', text: 'Our patent application was processed in record time. The AI search saved us weeks of manual work.', name: 'Anna Bell', location: 'USA, Texas', img: 'https://i.pravatar.cc/60?img=20' },
            { stars: 5, title: 'Highly Recommended', text: 'Patentify is a game changer for small inventors. Affordable and professional.', name: 'Michael Reed', location: 'USA, Oregon', img: 'https://i.pravatar.cc/60?img=15' },
            { stars: 5, title: 'Best in Class', text: 'Their automated drafting tool helped us avoid legal mistakes we would never have caught ourselves.', name: 'Sophie Clark', location: 'USA, New York', img: 'https://i.pravatar.cc/60?img=48' }
        ]
    ];

    var currentSet = 0;

    function renderTestimonials(setIndex) {
        if (!testimonialGrid) return;

        var starSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg>';
        var set = testimonialSets[setIndex];
        var html = '';

        set.forEach(function (t) {
            var stars = '';
            for (var i = 0; i < t.stars; i++) stars += starSvg;

            html +=
                '<div class="testimonial">' +
                    '<div class="stars">' + stars + '</div>' +
                    '<h3>' + t.title + '</h3>' +
                    '<p>' + t.text + '</p>' +
                    '<div class="author">' +
                        '<img src="' + t.img + '" alt="' + t.name + '">' +
                        '<div>' +
                            '<b>' + t.name + '</b>' +
                            '<span>' + t.location + '</span>' +
                        '</div>' +
                    '</div>' +
                '</div>';
        });

        testimonialGrid.innerHTML = html;

        if (pageIndicator) {
            pageIndicator.textContent = '0' + (setIndex + 1) + ' of 0' + testimonialSets.length;
        }
    }

    if (arrowBtns.length === 2) {
        arrowBtns[0].addEventListener('click', function () {
            currentSet = (currentSet - 1 + testimonialSets.length) % testimonialSets.length;
            renderTestimonials(currentSet);
        });

        arrowBtns[1].addEventListener('click', function () {
            currentSet = (currentSet + 1) % testimonialSets.length;
            renderTestimonials(currentSet);
        });
    }


    /* --------------------------------------------------------
       7. Подписка на рассылку в футере
       -------------------------------------------------------- */
    var subscribeForm = document.querySelector('.subscribe');

    if (subscribeForm) {
        var subscribeBtn = subscribeForm.querySelector('button');
        var subscribeInput = subscribeForm.querySelector('input');

        subscribeBtn.addEventListener('click', function () {
            var email = subscribeInput.value.trim();

            if (!email || !isValidEmail(email)) {
                showMessage('Please enter a valid email.', 'error');
                return;
            }

            showMessage('Subscribed successfully!', 'success');
            subscribeInput.value = '';
        });

        subscribeInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                subscribeBtn.click();
            }
        });
    }

});